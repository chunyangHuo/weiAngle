const picUrl = {
  activtyShare: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/20170904/card_share_4.jpg",
  activtyDetail: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/20170904/compete.jpg",
  activtyBanner: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/20170904/img-banner.png",
  page_workBench: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/jump.jpg",
  page_explainActivty: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/20170904/activtyContent.jpg",
  page_matchInvestorEmpty: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/example.png",
  shareCommon: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/20170904/card_share_2.jpg",
  banner_1: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/slide_banner_1.jpg",
  banner_2: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/slide_banner_2.jpg",
  banner_3: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/slide_banner_3.jpg",
  banner_4: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/slide_banner_4.jpg",
  banner_5: "https://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/slide_banner_5.jpg",
  banner_jump1: "http://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/click_jump_1.jpg",
  banner_jump2: "http://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/click_jump_2.jpg",
  banner_jump3: "http://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/click_jump_3.jpg",
  banner_jump4: "http://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/click_jump_4.jpg",
  banner_jump5: "http://weitianshi-2017.oss-cn-shanghai.aliyuncs.com/image/banner/click_jump_5.jpg",
}

export {
  picUrl
}