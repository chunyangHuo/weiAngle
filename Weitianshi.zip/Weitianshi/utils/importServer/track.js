var zhuge=wx.request('zhuge');
zhuge.load('d79a28abc0424fb499109b8a7d2a2e07');
module.exports = zhuge;
