let app=getApp();
Page({
  data:{
    url: app.globalData.picUrl.page_explainActivty
  }
})