// pages/remark/remarkList/remarkList.js
Page({
  data: {
  
  },
})