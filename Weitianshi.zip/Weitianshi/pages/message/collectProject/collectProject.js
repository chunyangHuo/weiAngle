// pages/message/collectProject/collectProject.js
Page({
  data: {
  
  },
})