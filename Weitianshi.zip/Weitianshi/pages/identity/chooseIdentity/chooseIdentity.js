var rqj = require('../../Template/Template.js')
var app = getApp();
var url = app.globalData.url;
var url_common = app.globalData.url_common;
// pages/identity/chooseIdentity/chooseIdentity.js
Page({
  data: {
  
  },
})