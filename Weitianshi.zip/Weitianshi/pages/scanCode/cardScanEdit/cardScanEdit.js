// pages/scanCode/cardScanEdit/cardScanEdit.js
Page({
  data: {
  
  },
  onLoad: function (options) {
  
  },
  onReady: function () {
  
  },
  onShow: function () {
  
  }
})